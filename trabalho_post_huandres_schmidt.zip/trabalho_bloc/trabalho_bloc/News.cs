﻿
namespace trabalho_bloc
{
    public class News : Post
    {
        private string Source { get; set; }

        public News(string title, DateTime date, string content, string source) : base(title, date, content)
        {
            Source = source;
        }

        public override void Show()
        {
            base.Show();
            Console.Write($"Source: {Source}\n");
        }
    }
}
