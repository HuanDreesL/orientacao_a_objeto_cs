﻿namespace trabalho_bloc
{
    public class Blog
    {
        private List<Post> ListPost { get; set; }

        public Blog() 
        {
            ListPost = new List<Post>();
        }

        public void ShowAll() 
        {
            foreach (Post posts in ListPost) 
            {
                Console.Write("Lista de Postagens\n");
                posts.Show();
            }
        }

        public void ReadData(Post post) 
        {
            ListPost.Add(post);
        }

        public Post GetPost(int index) 
        {
            if (index >= 0 && index < ListPost.Count)
            {
                return ListPost[index];
            }
            return null;
        }
    }
}
