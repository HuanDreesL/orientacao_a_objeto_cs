﻿namespace trabalho_bloc
{
    public class Post
    {
        private string Title { get; set; }
        private DateTime Date { get; set; }
        private string Content { get; set; }
        private int Dislikes { get; set; }
        private int Likes { get; set; }

        public Post(string title, DateTime date, string content) 
        {
            Title = title;
            Date = date;
            Content = content;
        }

        public virtual void Show() 
        {
            Console.Write($"\nTitulo: {Title}\n");
            Console.Write($"Data de Criação: {Date}\n");
            Console.Write($"Conteúdo: {Content}\n");
            Console.Write($"Quantidade de Dislikes: {Dislikes}\n");
            Console.Write($"Quantidade de Likes: {Likes}\n");
        }

        public virtual void Like() 
        {
            Console.Write($"Você deu Like no {Title}\n");
            Likes++;
        }

        public virtual void Dislike() 
        {
            Console.Write($"Você deu Dislike no {Title}\n");
            Dislikes++;
        }
    }
}
