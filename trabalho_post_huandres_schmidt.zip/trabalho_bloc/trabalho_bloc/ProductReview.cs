﻿
namespace trabalho_bloc
{
    public class ProductReview : Post
    {
        private string Brand { get; set; }
        private int Stars { get; set; }

        public ProductReview(string title, string content, DateTime date, string brand, int stars) : base(title: title, date: date, content: content)
        {
            Brand = brand;
            Stars = stars;
        }

        public override void Show()
        {
            base.Show();
            Console.Write($"Brand: {Brand}\n");
            Console.Write($"Avaliação: {Stars} Estrelas\n");
        }
    }
}
