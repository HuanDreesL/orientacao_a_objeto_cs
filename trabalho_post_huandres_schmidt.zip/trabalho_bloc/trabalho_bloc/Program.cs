﻿using System;

namespace trabalho_bloc
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Blog blog = new Blog();
            int decisao;

            do
            {
                Console.Write("BEM VINDO(A) AO BLOG\n");
                Console.Write("1. Novo post de notícia\n");
                Console.Write("2. Nova resenha de produto\n");
                Console.Write("3. Novo post de outros assuntos\n");
                Console.Write("4. Listar todas as postagens\n");
                Console.Write("5. Curtir uma postagem\n");
                Console.Write("6. Não curtir uma postagem\n");
                Console.Write("0. Sair do programa\n");

                Console.Write("\nOque Deseja Acessar: ");
                decisao = int.Parse(Console.ReadLine()!);

                switch (decisao) 
                {
                    case 1:
                        Console.Clear();
                        criarPostNoticia();
                        break;
                    case 2:
                        Console.Clear();
                        criarResenhaProduto();
                        break;
                    case 3:
                        Console.Clear();
                        criarOutroAssunto();
                        break;
                    case 4:
                        Console.Clear();
                        blog.ShowAll();
                        Console.ReadKey();
                        break;
                    case 5:
                        Console.Clear();
                        darLike();
                        break;
                    case 6:
                        Console.Clear();
                        darDislike();
                        break;
                    case 7:
                        Console.Write("Saindo do Programa....");
                        break;
                    default:
                        Console.Write("***COMANDO INVÁLIDO***");
                        break;
                }

            } while (decisao != 0);

            void criarPostNoticia() 
            {
                Console.Write("Titulo: ");
                string titulo = Console.ReadLine();

                Console.Write("Conteúdo da notícia\n:");
                string content = Console.ReadLine();

                Post noticiaPost = new Post(
                    title: titulo,
                    date: DateTime.Now,
                    content: content
                    );

                blog.ReadData(noticiaPost);
                Console.Clear();
            }

            void criarResenhaProduto() 
            {
                Console.Write("Nome Produto: ");
                string nomeProduto = Console.ReadLine();

                Console.Write("Sobre o Produto: \n");
                string content = Console.ReadLine();

                Console.Write("Brand: ");
                string brand = Console.ReadLine();

                Console.Write("Quantas Estrelas: ");
                int stars = int.Parse(Console.ReadLine());

                ProductReview resenhaProduto = new ProductReview(
                    title: nomeProduto,
                    content: content,
                    date: DateTime.Now,
                    brand: brand,
                    stars: stars
                    );

                blog.ReadData(resenhaProduto);
                Console.Clear();
            }

            void criarOutroAssunto()
            {
                Console.Write("Nome do Assunto: ");
                string nomeAssunto = Console.ReadLine();

                Console.Write("Sobre o Assunto: \n");
                string content = Console.ReadLine();

                Console.Write("Source: \n");
                string source = Console.ReadLine();

                News assunto = new News(title: nomeAssunto, date: DateTime.Now, content: content, source: source);

                blog.ReadData(assunto);
                Console.Clear();
            }

            void darLike() 
            {
                Console.Write("Digite o Indice da postagem: ");
                int indice = int.Parse(Console.ReadLine());

                Post post = blog.GetPost(indice);

                if (post != null) 
                {
                    post.Like();
                    return;
                }
                Console.Write("Postagem não encontrada!");
            }

            void darDislike() 
            {
                Console.Write("Digite o Indice da postagem: ");
                int indice = int.Parse(Console.ReadLine());

                Post post = blog.GetPost(indice);

                if (post != null)
                {
                    post.Dislike();
                    return;
                }
                Console.Write("Postagem não encontrada!");
            }
        }
    }
}
